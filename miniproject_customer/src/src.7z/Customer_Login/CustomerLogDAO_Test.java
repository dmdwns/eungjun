package Customer_Login;

import java.util.Scanner;

public class CustomerLogDAO_Test {
	
	public static void main(String[] args) {
		
		CustomerLogVO vo = new CustomerLogVO("", "");
		CustomerLogMethod clm = new CustomerLogMethod();
		clm.inputIdPw();
		StringBuffer sb = new StringBuffer();

	}

}










